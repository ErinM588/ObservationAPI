"""
Flask + TinyDB Point-of-Interest API
=====================================
A lightweight REST API for managing geographic points with reports.

Endpoints
---------
GET  /api/points          – Return every point in the database.
POST /api/points          – Create a new point (auto-assigns id).
GET  /api/points/search   – Query points by any combination of fields.
GET  /api/points/<id>     – Get a single point by its id.
PUT  /api/points/<id>     – Update a point (merge-patch style).
DELETE /api/points/<id>   – Delete a point by id.
POST /api/points/<id>/reports – Append a report to an existing point.

PythonAnywhere
--------------
To deploy on PythonAnywhere:
  1. Upload this project to /home/<username>/points-api/
  2. Create a new Web App → Manual config → Python 3.10+
  3. Set the Source code directory to /home/<username>/points-api/
  4. In the WSGI config file, add:
       import sys
       sys.path.insert(0, '/home/<username>/points-api')
       from app import app as application
  5. pip install flask tinydb (via a Bash console)
  6. Reload the web app.
"""

from flask import Flask, jsonify, request, render_template, abort
from tinydb import TinyDB, Query, where
from tinydb.operations import set as tinydb_set
import time, os, itertools

# ---------------------------------------------------------------------------
# App & DB setup
# ---------------------------------------------------------------------------
app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "points_db.json")
db = TinyDB(DB_PATH, indent=2)
points_table = db.table("points")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_id_counter = itertools.count(start=1)

def _next_id() -> int:
    """Return the next available integer id (survives restarts)."""
    existing = points_table.all()
    if existing:
        max_id = max(p.get("id", 0) for p in existing)
        return max_id + 1
    return 1


def _validate_point(data: dict, partial: bool = False) -> dict | None:
    """Validate incoming point data. Returns cleaned dict or None on error."""
    errors = []
    cleaned = {}

    if not partial or "name" in data:
        name = data.get("name")
        if not name or not isinstance(name, str):
            errors.append("'name' must be a non-empty string.")
        else:
            cleaned["name"] = name.strip()

    for coord in ("lat", "lon", "alt"):
        if not partial or coord in data:
            val = data.get(coord)
            if val is None and not partial:
                errors.append(f"'{coord}' is required.")
            elif val is not None:
                try:
                    cleaned[coord] = float(val)
                except (TypeError, ValueError):
                    errors.append(f"'{coord}' must be a number.")

    if "reports" in data:
        reps = data["reports"]
        if not isinstance(reps, list):
            errors.append("'reports' must be a list.")
        else:
            cleaned_reports = []
            for r in reps:
                if not isinstance(r, dict):
                    errors.append("Each report must be an object.")
                    break
                cleaned_reports.append({
                    "time": float(r.get("time", time.time())),
                    "text": str(r.get("text", "")),
                })
            cleaned["reports"] = cleaned_reports

    return (None, errors) if errors else (cleaned, [])


# ---------------------------------------------------------------------------
# API Routes
# ---------------------------------------------------------------------------

# ── 1) GET all points ─────────────────────────────────────────────────────
@app.route("/api/points", methods=["GET"])
def get_all_points():
    """Return every point in the database."""
    return jsonify({"count": len(points_table), "points": points_table.all()})


# ── 2) POST a new point ──────────────────────────────────────────────────
@app.route("/api/points", methods=["POST"])
def create_point():
    """Create a new point. Body must be JSON with name, lat, lon, alt."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Request body must be valid JSON."}), 400

    cleaned, errors = _validate_point(data)
    if errors:
        return jsonify({"error": "Validation failed.", "details": errors}), 400

    cleaned.setdefault("reports", [])
    cleaned["id"] = _next_id()

    points_table.insert(cleaned)
    return jsonify({"message": "Point created.", "point": cleaned}), 201


# ── 3) SEARCH / query points ─────────────────────────────────────────────
@app.route("/api/points/search", methods=["GET"])
def search_points():
    """
    Query points by any combination of fields via query-string parameters.

    Supported filters (all optional, combine with &):
      name=<substring>        case-insensitive substring match
      lat=<value>             exact numeric match
      lon=<value>             exact numeric match
      alt=<value>             exact numeric match
      lat_min / lat_max       range filter on latitude
      lon_min / lon_max       range filter on longitude
      alt_min / alt_max       range filter on altitude
      id=<int>                exact id match
      report_text=<substring> search inside report texts

    Example: /api/points/search?name=peak&alt_min=3000
    """
    Point = Query()
    conditions = []
    args = request.args

    # Substring match on name
    if "name" in args:
        needle = args["name"].lower()
        conditions.append(Point.name.test(lambda n: needle in n.lower()))

    # Exact numeric matches
    for field in ("lat", "lon", "alt"):
        if field in args:
            try:
                val = float(args[field])
                conditions.append(Point[field] == val)
            except ValueError:
                pass

    # Range filters
    for field in ("lat", "lon", "alt"):
        lo_key, hi_key = f"{field}_min", f"{field}_max"
        if lo_key in args:
            try:
                lo = float(args[lo_key])
                conditions.append(Point[field] >= lo)
            except ValueError:
                pass
        if hi_key in args:
            try:
                hi = float(args[hi_key])
                conditions.append(Point[field] <= hi)
            except ValueError:
                pass

    # Exact id
    if "id" in args:
        try:
            conditions.append(Point.id == int(args["id"]))
        except ValueError:
            pass

    # Search inside reports
    if "report_text" in args:
        needle = args["report_text"].lower()
        conditions.append(
            Point.reports.test(
                lambda reports: any(needle in r.get("text", "").lower() for r in reports)
            )
        )

    if not conditions:
        return jsonify({"error": "Provide at least one search parameter."}), 400

    # Combine all conditions with AND
    combined = conditions[0]
    for c in conditions[1:]:
        combined = combined & c

    results = points_table.search(combined)
    return jsonify({"count": len(results), "points": results})


# ── 4) GET single point ──────────────────────────────────────────────────
@app.route("/api/points/<int:point_id>", methods=["GET"])
def get_point(point_id):
    Point = Query()
    result = points_table.search(Point.id == point_id)
    if not result:
        return jsonify({"error": f"Point {point_id} not found."}), 404
    return jsonify({"point": result[0]})


# ── 5) UPDATE a point ────────────────────────────────────────────────────
@app.route("/api/points/<int:point_id>", methods=["PUT"])
def update_point(point_id):
    Point = Query()
    if not points_table.search(Point.id == point_id):
        return jsonify({"error": f"Point {point_id} not found."}), 404

    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Request body must be valid JSON."}), 400

    cleaned, errors = _validate_point(data, partial=True)
    if errors:
        return jsonify({"error": "Validation failed.", "details": errors}), 400

    for key, val in cleaned.items():
        points_table.update(tinydb_set(key, val), Point.id == point_id)

    updated = points_table.search(Point.id == point_id)[0]
    return jsonify({"message": "Point updated.", "point": updated})


# ── 6) DELETE a point ─────────────────────────────────────────────────────
@app.route("/api/points/<int:point_id>", methods=["DELETE"])
def delete_point(point_id):
    Point = Query()
    if not points_table.search(Point.id == point_id):
        return jsonify({"error": f"Point {point_id} not found."}), 404
    points_table.remove(Point.id == point_id)
    return jsonify({"message": f"Point {point_id} deleted."})


# ── 7) POST a report to a point ──────────────────────────────────────────
@app.route("/api/points/<int:point_id>/reports", methods=["POST"])
def add_report(point_id):
    Point = Query()
    results = points_table.search(Point.id == point_id)
    if not results:
        return jsonify({"error": f"Point {point_id} not found."}), 404

    data = request.get_json(silent=True)
    if not data or "text" not in data:
        return jsonify({"error": "'text' field is required."}), 400

    report = {
        "time": float(data.get("time", time.time())),
        "text": str(data["text"]),
    }

    existing = results[0]
    existing["reports"].append(report)
    points_table.update(tinydb_set("reports", existing["reports"]), Point.id == point_id)

    return jsonify({"message": "Report added.", "point": points_table.search(Point.id == point_id)[0]}), 201


# ---------------------------------------------------------------------------
# Web UI (serves the single-page dashboard)
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True, port=5000)
