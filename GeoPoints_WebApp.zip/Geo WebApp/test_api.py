"""Quick smoke test using Flask's built-in test client (no server needed)."""
import json, sys, os
sys.path.insert(0, os.path.dirname(__file__))

# Re-seed for a clean test
os.system("python seed_db.py")

from app import app

client = app.test_client()

def pp(label, resp):
    print(f"\n{'='*60}")
    print(f"  {label}  →  HTTP {resp.status_code}")
    print('='*60)
    print(json.dumps(resp.get_json(), indent=2)[:600])

# 1) GET all
pp("GET /api/points", client.get("/api/points"))

# 2) POST new point
pp("POST /api/points", client.post("/api/points",
    json={"name": "Test Peak", "lat": 40.0, "lon": -105.0, "alt": 3000.0}))

# 3) SEARCH by name
pp("SEARCH ?name=mount", client.get("/api/points/search?name=mount"))

# 4) SEARCH by altitude range
pp("SEARCH ?alt_min=3000", client.get("/api/points/search?alt_min=3000"))

# 5) SEARCH by report text
pp("SEARCH ?report_text=icy", client.get("/api/points/search?report_text=icy"))

# 6) GET single point
pp("GET /api/points/3", client.get("/api/points/3"))

# 7) POST report
pp("POST /api/points/2/reports", client.post("/api/points/2/reports",
    json={"text": "New trail closure on Kaibab."}))

# 8) PUT update
pp("PUT /api/points/5", client.put("/api/points/5",
    json={"name": "Key West Buoy", "alt": 1.0}))

# 9) DELETE
pp("DELETE /api/points/6", client.delete("/api/points/6"))

print("\n✓ All endpoints exercised successfully.")
