# Worked Examples

Each example uses the real seeded dataset (5 US landmarks — see the table in
`SKILL.md`). Results shown here match what the live API returns.

## List everything

```
python scripts/get_points.py
```

Returns `count: 5` with all seeded points. When presenting to a user,
summarize in natural language — don't dump the raw JSON.

## Search by name (substring, case-insensitive)

```
python scripts/search_points.py name=mount
```

Matches id 1 — Mount Rainier Summit.

```
python scripts/search_points.py name=canyon
```

Matches id 2 — Grand Canyon South Rim.

## Search by altitude range

```
python scripts/search_points.py alt_min=3000
```

Matches id 1 only (Mount Rainier at 4392 m is the only point above 3000 m
in the seed data).

```
python scripts/search_points.py alt_max=100
```

Matches id 5 — Key West (0.5 m).

## Search by latitude range (northern points)

```
python scripts/search_points.py lat_min=60
```

Matches id 4 — Denali Base Camp (63.07° N).

## Search report text

```
python scripts/search_points.py report_text=icy
```

Matches id 1 — Mount Rainier has a report containing "icy conditions".

```
python scripts/search_points.py report_text=eruption
```

Matches id 3 — Yellowstone Old Faithful has a report about the eruption
interval.

## Combined search (AND)

```
python scripts/search_points.py name=mount alt_min=3000
```

Matches id 1 — both conditions true.

```
python scripts/search_points.py name=canyon alt_min=3000
```

Returns `count: 0` — Grand Canyon South Rim is below 3000 m. If the user
expected a result, relax one filter at a time.

## Get a single point

```
python scripts/get_point.py 3
```

Returns Yellowstone Old Faithful with both of its reports.

## Add a new point

Check for duplicates first, then create:

```
python scripts/search_points.py name=hood
python scripts/create_point.py "Mount Hood" 45.3735 -121.6959 3429
```

The server assigns id 6 (next available).

## Add a report to an existing point

```
python scripts/add_report.py 3 "Boardwalk repairs completed, full access restored."
```

The report is appended to Yellowstone Old Faithful with the current
Unix timestamp. Response returns the full updated point.

## Delete a point

Confirm with the user first:

```
python scripts/get_point.py 6
python scripts/delete_point.py 6
```

## Error handling

- **URL unreachable** — `POINTS_API_URL` is wrong or the server is down.
- **HTTP 404** — id doesn't exist. Run `get_points.py` to list valid ids
  (seeded ids are 1–5; new points get 6, 7, … as they're created).
- **HTTP 400** — validation failed. The response's `details` array lists
  which fields were invalid.
