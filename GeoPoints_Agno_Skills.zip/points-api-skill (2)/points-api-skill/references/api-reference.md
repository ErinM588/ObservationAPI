# Points API — Full Reference

## Base URL

All endpoints are relative to the deployed site root, e.g.
`https://ekwf.pythonanywhere.com`. Scripts read this from the
`POINTS_API_URL` environment variable.

## Authentication

None. The API is currently open. Deploy behind an auth proxy if you need
access control.

## Content Types

All request bodies are `application/json`. All responses are
`application/json` except for the root `/` which serves the HTML dashboard.

---

## Endpoints

### `GET /api/points`

Return every point in the database.

**Response 200**

```json
{
  "count": 5,
  "points": [
    {
      "id": 1,
      "name": "Mount Rainier Summit",
      "lat": 46.8523,
      "lon": -121.7603,
      "alt": 4392.0,
      "reports": [
        { "time": 1712345678.0, "text": "Clear skies." }
      ]
    }
  ]
}
```

---

### `POST /api/points`

Create a new point. The server auto-assigns `id`.

**Request body**

```json
{
  "name": "Mount Hood",
  "lat":  45.3735,
  "lon":  -121.6959,
  "alt":  3429.0
}
```

Optional: include a `reports` array to seed initial reports.

**Response 201**

```json
{
  "message": "Point created.",
  "point": {
    "id": 6,
    "name": "Mount Hood",
    "lat": 45.3735,
    "lon": -121.6959,
    "alt": 3429.0,
    "reports": []
  }
}
```

**Response 400** — validation failure. Body includes `error` and `details` array.

---

### `GET /api/points/search`

Filter points by any combination of query-string parameters. All filters
combine with AND semantics.

| Parameter | Type | Behaviour |
| --- | --- | --- |
| `name` | string | case-insensitive substring match |
| `id` | int | exact match |
| `lat`, `lon`, `alt` | float | exact numeric match |
| `lat_min`, `lat_max` | float | latitude range (inclusive) |
| `lon_min`, `lon_max` | float | longitude range (inclusive) |
| `alt_min`, `alt_max` | float | altitude range (inclusive) |
| `report_text` | string | substring within any report's text |

At least one parameter is required.

**Response 200**

```json
{
  "count": 2,
  "points": [ /* matching points */ ]
}
```

**Response 400** — no parameters supplied.

---

### `GET /api/points/<id>`

Get a single point by its integer id.

**Response 200** — `{ "point": {...} }`
**Response 404** — point does not exist.

---

### `PUT /api/points/<id>`

Partial update. Only include the fields you want to change. Returns the
updated point.

**Request body**

```json
{ "name": "New Name", "alt": 3500 }
```

**Response 200** — `{ "message": "Point updated.", "point": {...} }`
**Response 400** / **404** — on validation/missing id.

---

### `DELETE /api/points/<id>`

Delete a point and all its reports.

**Response 200** — `{ "message": "Point N deleted." }`
**Response 404** — point does not exist.

---

### `POST /api/points/<id>/reports`

Append a report to an existing point. The server stamps `time` with the
current Unix timestamp unless the body supplies one.

**Request body**

```json
{ "text": "Trail closed above 3000 m due to ice." }
```

Optional: supply `time` to backdate.

**Response 201** — returns the full updated point (useful for confirming the
report was added).
**Response 400** — missing `text`.
**Response 404** — point does not exist.

---

## Error Format

All error responses are JSON:

```json
{ "error": "Short reason.", "details": ["optional", "list"] }
```

## Validation Rules

- `name`: non-empty string, trimmed.
- `lat`, `lon`, `alt`: must coerce to `float`.
- Client-side convention (not enforced by server): `-90 ≤ lat ≤ 90`,
  `-180 ≤ lon ≤ 180`. Scripts in this skill enforce these ranges.

## Rate Limits

None. If deployed on PythonAnywhere free tier, the site may cold-start
after inactivity (first request takes a few extra seconds).
