#!/usr/bin/env python3
"""Search the Points database by any combination of fields.

Usage:
    python scripts/search_points.py <key=value> [<key=value> ...]

Supported keys:
    name=<substring>          case-insensitive name match
    id=<int>                  exact id match
    lat=<f>  lon=<f>  alt=<f> exact coordinate match
    lat_min / lat_max         latitude range
    lon_min / lon_max         longitude range
    alt_min / alt_max         altitude range
    report_text=<substring>   substring within any report

Example:
    python scripts/search_points.py name=mount alt_min=3000
"""
import sys
from _common import api_call, qs, pretty

ALLOWED = {
    "name", "id",
    "lat", "lon", "alt",
    "lat_min", "lat_max",
    "lon_min", "lon_max",
    "alt_min", "alt_max",
    "report_text",
}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: search_points.py key=value [key=value ...]", file=sys.stderr)
        print("Supported keys: " + ", ".join(sorted(ALLOWED)), file=sys.stderr)
        sys.exit(2)

    params = {}
    for arg in sys.argv[1:]:
        if "=" not in arg:
            print(f"Bad argument '{arg}': expected key=value.", file=sys.stderr)
            sys.exit(2)
        key, value = arg.split("=", 1)
        key = key.strip()
        if key not in ALLOWED:
            print(f"Unknown search key '{key}'.", file=sys.stderr)
            print("Supported keys: " + ", ".join(sorted(ALLOWED)), file=sys.stderr)
            sys.exit(2)
        params[key] = value.strip()

    result = api_call("GET", "/api/points/search" + qs(params))
    pretty(result)
