#!/usr/bin/env python3
"""Create a new point in the database.

Usage:
    python scripts/create_point.py <name> <lat> <lon> <alt>

Example:
    python scripts/create_point.py "Mount Hood" 45.3735 -121.6959 3429

The server auto-assigns an integer id. Latitude must be in [-90, 90],
longitude in [-180, 180]. Altitude is in meters.
"""
import sys
from _common import api_call, pretty

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print('Usage: create_point.py "<name>" <lat> <lon> <alt>', file=sys.stderr)
        sys.exit(2)

    name = sys.argv[1].strip()
    if not name:
        print("Name cannot be empty.", file=sys.stderr)
        sys.exit(2)

    try:
        lat = float(sys.argv[2])
        lon = float(sys.argv[3])
        alt = float(sys.argv[4])
    except ValueError as e:
        print(f"Invalid numeric argument: {e}", file=sys.stderr)
        sys.exit(2)

    if not -90 <= lat <= 90:
        print(f"Latitude {lat} out of range [-90, 90].", file=sys.stderr)
        sys.exit(2)
    if not -180 <= lon <= 180:
        print(f"Longitude {lon} out of range [-180, 180].", file=sys.stderr)
        sys.exit(2)

    body = {"name": name, "lat": lat, "lon": lon, "alt": alt}
    result = api_call("POST", "/api/points", body)
    pretty(result)
