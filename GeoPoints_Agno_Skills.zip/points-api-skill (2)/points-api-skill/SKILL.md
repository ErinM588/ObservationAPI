---
name: points-api
description: Interact with the Points API — a Flask + TinyDB REST service for managing geographic points with lat/lon/altitude and timestamped text reports. Use this skill when the user asks to list, search, create, update, or annotate points.
license: MIT
metadata:
  version: "1.0.0"
  tags: ["geospatial", "rest-api"]
---

# Points API Skill

Interact with a deployed Points API: a Flask + TinyDB REST service that stores
geographic points and timestamped text reports about each one. The database is
pre-seeded with five US landmarks:

| id | name | lat | lon | alt (m) |
| -- | ---- | --- | --- | ------- |
| 1 | Mount Rainier Summit       | 46.8523 | -121.7603 | 4392.0 |
| 2 | Grand Canyon South Rim     | 36.0544 | -112.1401 | 2100.0 |
| 3 | Yellowstone Old Faithful   | 44.4605 | -110.8281 | 2240.0 |
| 4 | Denali Base Camp           | 63.0695 | -151.0074 | 2195.0 |
| 5 | Key West Southernmost Point| 24.5465 |  -81.7986 |    0.5 |

## When to Use

- List or browse points in the database.
- Create a new point with a name, latitude, longitude, and altitude.
- Search by name, coordinate ranges, altitude ranges, or report text.
- Add a report (observation, condition note) to an existing point.
- Get, update, or delete a point by its integer id.

## Configuration

Set `POINTS_API_URL` to the deployed site root before running any script:

```
export POINTS_API_URL="https://yourname.pythonanywhere.com"
```

If unset, scripts default to `http://127.0.0.1:5000` for local dev.

## Point Schema

```json
{
  "id":      1,
  "name":    "Mount Rainier Summit",
  "lat":     46.8523,
  "lon":     -121.7603,
  "alt":     4392.0,
  "reports": [
    { "time": 1712345678.0, "text": "Clear skies, winds calm at summit." }
  ]
}
```

- `id` is assigned by the server on creation — do not supply it.
- `lat`, `lon`, `alt` are floats. Altitude is in meters.
- `reports` is a list of `{time, text}` objects. `time` is a Unix timestamp.

## Available Scripts

| Script | Purpose |
| --- | --- |
| `scripts/get_points.py` | Fetch every point. No args. |
| `scripts/get_point.py` | Fetch one point. Args: `<id>`. |
| `scripts/create_point.py` | Create a new point. Args: `<n> <lat> <lon> <alt>`. |
| `scripts/search_points.py` | Search by fields. Args: `key=value ...` |
| `scripts/add_report.py` | Add a report. Args: `<id> "<text>"`. |
| `scripts/delete_point.py` | Delete a point. Args: `<id>`. |

Each script prints the JSON response to stdout and exits non-zero on HTTP or
validation errors (error detail on stderr).

## Search Parameters

- `name=<substring>` — case-insensitive
- `id=<int>` — exact match
- `lat`, `lon`, `alt` — exact float match
- `lat_min` / `lat_max`, `lon_min` / `lon_max`, `alt_min` / `alt_max` — ranges
- `report_text=<substring>` — searches inside all reports

Multiple parameters combine with AND. Full spec in `references/api-reference.md`.
Worked examples in `references/examples.md`.

## Notes

- Scripts validate lat ∈ [-90, 90] and lon ∈ [-180, 180] before sending.
- Timestamps are Unix floats; convert with `datetime.fromtimestamp(t)` when
  presenting to a user.
